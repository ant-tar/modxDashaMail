<?php

$_lang['dashamail_prop_tpl'] = 'The chunk to use for checkbox view';
