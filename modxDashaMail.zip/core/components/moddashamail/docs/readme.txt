--------------------
modDashaMail
--------------------
Author: Anton Tarasov <contact@antontarasov.com>
--------------------

MODX Extra for interaction with DashaMail (https://dashamail.ru) service