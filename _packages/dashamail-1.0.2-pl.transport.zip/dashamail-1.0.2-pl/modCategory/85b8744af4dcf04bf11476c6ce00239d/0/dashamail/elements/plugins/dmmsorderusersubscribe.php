<?php
if (!$modx->getService('miniShop2')) {
    return;    
}

switch ($modx->event->name) {
   case 'msOnCreateOrder':
      $msAddress = $msOrder->getOne('Address');
      $dmListID = $modx->getOption('dashamail_list_id');
      $msSubscription = $msAddress->get('dmsubscription');
      $msPhone = $msAddress->get('phone');
      $msEmail = $msAddress->get('email');
      $msAddressReceiver = $msAddress->get('receiver');
      if($msSubscription){
          $modx->log(modX::LOG_LEVEL_ERROR, 'checkbox is active', '', 'sendOrder');
        $dashamail = $modx->getService('dashamail','DashaMail',$modx->getOption('dashamail.core_path',null,$modx->getOption('core_path').'components/dashamail/').'model/dashamail/',[]);
        if (!($dashamail instanceof DashaMail)) {
            return;
        }
        $dm = new DashaMail($modx);
        
        $mergeData = [];
        $dmMergeParams = $modx->getOption('dashamail_merge_fields');
        if(!empty($dmMergeParams)){
        
            //process merge array params
            
            foreach ($dmMergeParams as $mergeParam){
                list($key,$value) = explode('==', $mergeParam);
                $mergeData[$key] = $formValues[$value];
            }
        }
        $mergeData = ['merge_6' => $msPhone, 'merge_4' => $msAddressReceiver]; // TBD
        $modx->log(modX::LOG_LEVEL_ERROR, 'merge params='.print_r($mergeData,true), '', 'sendOrder');
        $listMember = $dm->addListMember($dmListID, $msEmail, $mergeData);
      }
    break;
}