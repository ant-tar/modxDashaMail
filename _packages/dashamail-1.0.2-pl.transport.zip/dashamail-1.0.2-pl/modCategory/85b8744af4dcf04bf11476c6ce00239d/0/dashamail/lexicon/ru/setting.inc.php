<?php

$_lang['area_dashamail_main'] = 'Главная';

$_lang['setting_dashamail_api_key'] = 'API ключ';
$_lang['setting_dashamail_api_key_desc'] = 'Возьмите его из настроек сервиса DashaMail';

$_lang['setting_dashamail_list_id'] = 'ID адресной базы';
$_lang['setting_dashamail_list_id_desc'] = 'Возьмите его из настроек сервиса DashaMail, этот ID указан в URL адресе страницы списка пользователей';

$_lang['setting_dashamail_merge_fields'] = 'Список полей подстановки по умолчанию';
$_lang['setting_dashamail_merge_fields_desc'] = 'Будет использован, если он нигде далее переопределен, например, в хуке';

$_lang['setting_dashamail_checkbox_name'] = 'Имя поля чекбокса';
$_lang['setting_dashamail_checkbox_name_desc'] = 'Имя input поля для подтверждения подписки, если значение пустое  - подтверждение не требуется';