<?php

return [
    'tpl.modDashaMail.item' => [
        'file' => 'item',
        'description' => '',
    ],
    'tpl.modDashaMail.office' => [
        'file' => 'office',
        'description' => '',
    ],
];