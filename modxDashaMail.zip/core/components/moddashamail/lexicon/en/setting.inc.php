<?php

$_lang['area_moddashamail_main'] = 'Main';

$_lang['setting_moddashamail_api_key'] = 'API key';
$_lang['setting_moddashamail_api_key_desc'] = 'Take it from DashaMail website';