## modDashaMail
MODX Extra for interaction with DashaMail(https://dashamail.ru) service

## Installation
Install the extra via MODX package manager

## Create API Key
Signup for an account on https://dashamail.ru and create an API key, here are more details: https://dashamail.ru/api/?_gl=1*rf286y*_ga*MTY0NjI0Mzg4NC4xNzM2OTI3MzA0*_ga_HWEQYTTCPL*MTczODQ0MDgwOS4xMC4xLjE3Mzg0NDA5MjAuMjAuMC4w

## System settings
Add API key to your system settings
