<?php

return [
    'modDashaMail' => [
        'description' => '',
        'type' => 'file',
        'content' => '',
        'namespace' => 'moddashamail',
        'lexicon' => 'moddashamail:dashboards',
        'size' => 'half',
    ],
];