<?php

$_lang['area_dashamail_main'] = 'Main';

$_lang['setting_dashamail_api_key'] = 'API key';
$_lang['setting_dashamail_api_key_desc'] = 'Take it from DashaMail website';

$_lang['setting_dashamail_list_id'] = 'User list ID';
$_lang['setting_dashamail_list_id_desc'] = 'Take it from DashaMail website';


