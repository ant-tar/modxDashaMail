<?php

return [
    'modDashaMail' => [
        'file' => 'moddashamail',
        'description' => '',
        'events' => [
            'OnManagerPageInit' => [],
        ],
    ],
];