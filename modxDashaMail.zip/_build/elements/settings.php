<?php

return [
    'api_key' => [
        'xtype' => 'textfield',
        'value' => '',
        'area' => 'moddashamail_main',
    ],
];