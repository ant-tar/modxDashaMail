<?php

return [
    'modDashaMailUserPolicyTemplate' => [
        'description' => 'modDashaMail policy template description.',
        'template_group' => 1,
        'permissions' => [
            'moddashamail_save' => [],
        ]
    ],
];