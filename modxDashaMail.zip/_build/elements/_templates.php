<?php

return [
    'BaseTemplate' => [
        'file' => 'base',
        'description' => 'Base template',
    ],
];