
MODX Extra for interaction with DashaMail service