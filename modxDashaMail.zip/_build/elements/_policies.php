<?php

return [
    'modDashaMailUserPolicy' => [
        'description' => 'modDashaMail policy description.',
        'data' => [
            'moddashamail_save' => true,
        ]
    ],
];