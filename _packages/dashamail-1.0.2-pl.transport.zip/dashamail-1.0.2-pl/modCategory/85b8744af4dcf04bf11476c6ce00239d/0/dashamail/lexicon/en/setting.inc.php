<?php

$_lang['area_dashamail_main'] = 'Main';

$_lang['setting_dashamail_api_key'] = 'API key';
$_lang['setting_dashamail_api_key_desc'] = 'Take it from DashaMail website settings';

$_lang['setting_dashamail_list_id'] = 'User list ID';
$_lang['setting_dashamail_list_id_desc'] = 'Take it from DashaMail website, basically this is list ID from page URL';

$_lang['setting_dashamail_merge_fields'] = 'Default merge list';
$_lang['setting_dashamail_merge_fields_desc'] = 'If not redefined this one will be used by default';

$_lang['setting_dashamail_checkbox_name'] = 'Checkbox field name';
$_lang['setting_dashamail_checkbox_name_desc'] = 'Checkbox name for subscription confirmation, empty value means no confirmation';